EASEMODEL = "D:/gleb/Recsys_projeccts/sirius_seminars/vkusvill_case/src/ease_pipeline/data/ease_model.pkl"
MAPPING = "D:/gleb/Recsys_projeccts/sirius_seminars/vkusvill_case/src/ease_pipeline/data/items_dict.json"
TOPPOPULAR = "D:/gleb/Recsys_projeccts/sirius_seminars/vkusvill_case/src/ease_pipeline/data/toppop_model.pkl"
VKUSVILL_MAPPING = "D:/gleb/Recsys_projeccts/sirius_seminars/vkusvill_case/src/ease_pipeline/data/cooker2vkussvil.json"
